﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading.Tasks;

namespace HesapMakinesi
{
    class Program
    {
        static void Main(string[] args)
        {
            double number1;
            string number1string;
            double number2;
            string number2string;
            string calculation;
            double result;

            Console.WriteLine("EREN CEYLAN'S CALCULATOR");
           
            Console.WriteLine("Enter the first number");
            number1string = Console.ReadLine();
            number1 = Convert.ToDouble(number1string);
            Console.WriteLine("Enter the second number");
            number2 = Convert.ToDouble(Console.ReadLine());
            result =number1 + number2;
            Console.WriteLine("Sum is " + result);
            result = number1 - number2;
            Console.WriteLine("subtraction is"+result);

            Console.ReadLine();
        }
    }
}
