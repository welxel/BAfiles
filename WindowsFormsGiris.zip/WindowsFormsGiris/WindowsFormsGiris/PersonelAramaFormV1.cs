﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsGiris
{
    public partial class PersonelAramaFormV1 : Form
    {
        string[] personeller;

        public PersonelAramaFormV1()
        {
            InitializeComponent();
        }

        private void PersonelAramaFormV1_Load(object sender, EventArgs e)
        {
            personeller = new string[]
            {
                "Çağıl Alsaç", // 6 soyad.length, 11 tamad.length, 11 - 6 = 5 tamad.length - soyad.length; soyad.length + 1, lower üzerinden substring, array üzerinden adı oluşturmak
                "Tahsin Kılınçarslan",
                "Furkan Tüzün",
                "Enes Bartu Ünal",
                "Tolga Karadoğan",
                "Naci Yirik",
                "Yiğit Arif Memeci",
                "Leo Alsaç"
            };
            lSonuc.Text = "";
            cbKosul.Items.Add("ve"); // 0
            cbKosul.Items.Add("veya"); // 1
            cbKosul.SelectedIndex = 0;
        }

        private void bTemizle_Click(object sender, EventArgs e)
        {
            tbAd.Clear();
            tbSoyad.Text = "";
            lSonuc.Text = "";
        }

        private void bAra_Click(object sender, EventArgs e)
        {
            string tmpPersonelLower, ad, soyad;
            string[] tmpPersonelSplit;
            string sonuc = "";
            foreach (var personel in personeller)
            {
                tmpPersonelLower = personel.ToLower();
                tmpPersonelSplit = tmpPersonelLower.Split(' ');
                soyad = tmpPersonelSplit[tmpPersonelSplit.Length - 1];

                //ad = tmpPersonelLower.Substring(0, tmpPersonelLower.Length - (soyad.Length + 1));
                ad = "";
                for (int i = 0; i < tmpPersonelSplit.Length - 1; i++)
                {
                    ad += tmpPersonelSplit[i] + " ";
                }
                ad = ad.Trim();

                //sonuc += ad + " " + soyad + "\n";

                if (cbKosul.SelectedIndex == 0)
                {
                    if (ad.Contains(tbAd.Text.ToLower().Trim()) && tbAd.Text.Trim() != "" && soyad.Contains(tbSoyad.Text.ToLower().Trim()) && tbSoyad.Text.Trim() != "")
                        sonuc += personel + "\n";
                }
                else
                {
                    if ((ad.Contains(tbAd.Text.ToLower().Trim()) && tbAd.Text.Trim() != "") || (soyad.Contains(tbSoyad.Text.ToLower().Trim()) && tbSoyad.Text.Trim() != ""))
                        sonuc += personel + "\n";
                }
            }
            if (sonuc == "")
                lSonuc.Text = "Kayıt bulunamadı.";
            else
                lSonuc.Text = sonuc;
        }
    }
}
