﻿namespace WindowsFormsGiris
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lHelloWorld = new System.Windows.Forms.Label();
            this.tbAd = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbSoyad = new System.Windows.Forms.TextBox();
            this.bGonder = new System.Windows.Forms.Button();
            this.lSonuc = new System.Windows.Forms.Label();
            this.bQuit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lHelloWorld
            // 
            this.lHelloWorld.AutoSize = true;
            this.lHelloWorld.Location = new System.Drawing.Point(12, 10);
            this.lHelloWorld.Name = "lHelloWorld";
            this.lHelloWorld.Size = new System.Drawing.Size(69, 18);
            this.lHelloWorld.TabIndex = 0;
            this.lHelloWorld.Text = "Personel";
            // 
            // tbAd
            // 
            this.tbAd.Location = new System.Drawing.Point(76, 38);
            this.tbAd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbAd.Name = "tbAd";
            this.tbAd.Size = new System.Drawing.Size(302, 26);
            this.tbAd.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(15, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 23);
            this.label2.TabIndex = 2;
            this.label2.Text = "Ad";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(15, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 23);
            this.label3.TabIndex = 4;
            this.label3.Text = "Soyad";
            // 
            // tbSoyad
            // 
            this.tbSoyad.Location = new System.Drawing.Point(76, 66);
            this.tbSoyad.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbSoyad.Name = "tbSoyad";
            this.tbSoyad.Size = new System.Drawing.Size(302, 26);
            this.tbSoyad.TabIndex = 3;
            // 
            // bGonder
            // 
            this.bGonder.Location = new System.Drawing.Point(301, 97);
            this.bGonder.Name = "bGonder";
            this.bGonder.Size = new System.Drawing.Size(75, 34);
            this.bGonder.TabIndex = 5;
            this.bGonder.Text = "Gönder";
            this.bGonder.UseVisualStyleBackColor = true;
            this.bGonder.Click += new System.EventHandler(this.bGonder_Click);
            // 
            // lSonuc
            // 
            this.lSonuc.BackColor = System.Drawing.Color.LightCoral;
            this.lSonuc.Location = new System.Drawing.Point(15, 134);
            this.lSonuc.Name = "lSonuc";
            this.lSonuc.Size = new System.Drawing.Size(361, 25);
            this.lSonuc.TabIndex = 6;
            // 
            // bQuit
            // 
            this.bQuit.Location = new System.Drawing.Point(300, 276);
            this.bQuit.Name = "bQuit";
            this.bQuit.Size = new System.Drawing.Size(75, 38);
            this.bQuit.TabIndex = 7;
            this.bQuit.Text = "Çıkış";
            this.bQuit.UseVisualStyleBackColor = true;
            this.bQuit.Click += new System.EventHandler(this.bQuit_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.bGonder;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(388, 326);
            this.Controls.Add(this.bQuit);
            this.Controls.Add(this.bGonder);
            this.Controls.Add(this.lSonuc);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbSoyad);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbAd);
            this.Controls.Add(this.lHelloWorld);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ForeColor = System.Drawing.Color.Black;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Windows Forms Intro";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lHelloWorld;
        private System.Windows.Forms.TextBox tbAd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbSoyad;
        private System.Windows.Forms.Button bGonder;
        private System.Windows.Forms.Label lSonuc;
        private System.Windows.Forms.Button bQuit;
    }
}

