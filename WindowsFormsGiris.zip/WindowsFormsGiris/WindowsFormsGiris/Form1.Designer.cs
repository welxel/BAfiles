﻿namespace WindowsFormsGiris
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbAdi = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbSoyadi = new System.Windows.Forms.TextBox();
            this.bGoster = new System.Windows.Forms.Button();
            this.lAdSoyad = new System.Windows.Forms.Label();
            this.bTemizle = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Adı";
            // 
            // tbAdi
            // 
            this.tbAdi.Font = new System.Drawing.Font("Comic Sans MS", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbAdi.Location = new System.Drawing.Point(127, 12);
            this.tbAdi.Name = "tbAdi";
            this.tbAdi.Size = new System.Drawing.Size(272, 37);
            this.tbAdi.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(12, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 29);
            this.label2.TabIndex = 3;
            this.label2.Text = "Soyadı";
            // 
            // tbSoyadi
            // 
            this.tbSoyadi.Font = new System.Drawing.Font("Comic Sans MS", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbSoyadi.Location = new System.Drawing.Point(127, 55);
            this.tbSoyadi.Name = "tbSoyadi";
            this.tbSoyadi.Size = new System.Drawing.Size(272, 37);
            this.tbSoyadi.TabIndex = 4;
            // 
            // bGoster
            // 
            this.bGoster.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bGoster.Location = new System.Drawing.Point(127, 98);
            this.bGoster.Name = "bGoster";
            this.bGoster.Size = new System.Drawing.Size(104, 34);
            this.bGoster.TabIndex = 5;
            this.bGoster.Text = "Göster";
            this.bGoster.UseVisualStyleBackColor = true;
            this.bGoster.Click += new System.EventHandler(this.bGoster_Click);
            // 
            // lAdSoyad
            // 
            this.lAdSoyad.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lAdSoyad.Location = new System.Drawing.Point(12, 159);
            this.lAdSoyad.Name = "lAdSoyad";
            this.lAdSoyad.Size = new System.Drawing.Size(869, 65);
            this.lAdSoyad.TabIndex = 6;
            this.lAdSoyad.Text = "lAdSoyad";
            this.lAdSoyad.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bTemizle
            // 
            this.bTemizle.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bTemizle.Location = new System.Drawing.Point(237, 98);
            this.bTemizle.Name = "bTemizle";
            this.bTemizle.Size = new System.Drawing.Size(104, 34);
            this.bTemizle.TabIndex = 5;
            this.bTemizle.Text = "Temizle";
            this.bTemizle.UseVisualStyleBackColor = true;
            this.bTemizle.Click += new System.EventHandler(this.bTemizle_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(893, 416);
            this.Controls.Add(this.lAdSoyad);
            this.Controls.Add(this.bTemizle);
            this.Controls.Add(this.bGoster);
            this.Controls.Add(this.tbSoyadi);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbAdi);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Windows Forms Giriş";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbAdi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbSoyadi;
        private System.Windows.Forms.Button bGoster;
        private System.Windows.Forms.Label lAdSoyad;
        private System.Windows.Forms.Button bTemizle;
    }
}

