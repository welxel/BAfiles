﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsGiris
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

      

        private void Form1_Load(object sender, EventArgs e)
        {
            lAdSoyad.Text = "";
        }

        private void bGoster_Click(object sender, EventArgs e)
        {
            string a = null;
            string b = "";
            string c = " ";

            //int s = a.Length;
            int s = b.Length;

            //if (tbAdi.Text.Trim() == "" || tbSoyadi.Text.Trim() == "")
            if (String.IsNullOrWhiteSpace(tbAdi.Text) || string.IsNullOrWhiteSpace(tbSoyadi.Text))
            {
                lAdSoyad.Text = "Lütfen ad ve soyad giriniz.";
                lAdSoyad.ForeColor = Color.Red;
                MessageBox.Show(lAdSoyad.Text, "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                lAdSoyad.Text = tbAdi.Text + " " + tbSoyadi.Text;
                lAdSoyad.ForeColor = Color.Black;
            }
        }

        private void bTemizle_Click(object sender, EventArgs e)
        {
            //lAdSoyad.ForeColor = Color.Black;
            tbAdi.Text = "";
            tbSoyadi.Clear();
            lAdSoyad.Text = "";
            
        }
    }
}
