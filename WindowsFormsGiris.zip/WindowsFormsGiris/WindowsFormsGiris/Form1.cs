﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsGiris
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //lHelloWorld.Text = "Merhaba Dünya!";
            //lHelloWorld.ForeColor = Color.Red;
        }

        private void bGonder_Click(object sender, EventArgs e)
        {
            //string ad, soyad, sonuc;
            //ad = tbAd.Text;
            //soyad = tbSoyad.Text;
            //sonuc = ad + " " + soyad;
            //lSonuc.Text = sonuc;
            string ad = tbAd.Text.Trim();
            string soyad = tbSoyad.Text.Trim();
            if (ad != "" && soyad != "")
            {
                lSonuc.Text = ad + " " + soyad;
            }
            else
            {
                lSonuc.Text = "Ad ve soyad giriniz.";
                MessageBox.Show("Ad ve soyad giriniz.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void bQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
