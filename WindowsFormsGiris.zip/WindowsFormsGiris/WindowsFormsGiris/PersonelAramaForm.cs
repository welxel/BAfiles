﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsGiris
{
    public partial class PersonelAramaForm : Form
    {
        string[] personeller; // global değişken

        public PersonelAramaForm()
        {
            InitializeComponent();
        }

        private void PersonelAramaForm_Load(object sender, EventArgs e)
        {
            personeller = new string[]
            {
                "Çağıl Alsaç",
                "Tahsin Kılınçarslan",
                "Furkan Tüzün",
                "Enes Bartu Ünal",
                "Tolga Karadoğan",
                "Naci Yirik",
                "Yiğit Arif Memeci",
                "Leo Alsaç"
            };
            lSonuc.Text = "";
        }

        private void bTemizle_Click(object sender, EventArgs e)
        {
            tbAd.Clear();
            tbSoyad.Text = "";
            lSonuc.Text = "";
        }

        private void bAra_Click(object sender, EventArgs e)
        {
            //string bugun = "Çarşamba"; // local değişken
            string sonuc = "";
            string ad, soyad;
            string[] tmpPersonel; 
            foreach (var personel in personeller)
            {
                ad = "";
                tmpPersonel = personel.Split(' ');
                soyad = tmpPersonel[tmpPersonel.Length - 1];
                if (tmpPersonel.Length == 2)
                {
                    ad = tmpPersonel[0];
                }
                else
                {
                    for (int i = 0; i < tmpPersonel.Length - 1; i++)
                    {
                        ad += tmpPersonel[i] + " ";
                    }
                }
                //if (personel.ToLower().Contains(tbAd.Text.ToLower().Trim() + " " + tbSoyad.Text.ToLower().Trim()))
                //if (personel.ToLower().Contains(tbAd.Text.ToLower().Trim()) || personel.ToLower().Contains(tbSoyad.Text.ToLower().Trim()))
                if (ad.ToLower().StartsWith(tbAd.Text.ToLower().Trim()) || soyad.ToLower().StartsWith(tbSoyad.Text.ToLower().Trim()))
                    sonuc += personel + "\n";
            }
            if (sonuc.Equals(""))
                lSonuc.Text = "Kayıt bulunamadı.";
            else
                lSonuc.Text = sonuc;
        }
    }
}
