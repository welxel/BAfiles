﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsGiris
{
    public partial class PersonelAramaForm : Form
    {
        string[] personeller; // global değişken

        public PersonelAramaForm()
        {
            InitializeComponent();
        }

        private void PersonelAramaForm_Load(object sender, EventArgs e)
        {
            personeller = new string[]
            {
                "Çağıl Alsaç",
                "Tahsin Kılınçarslan",
                "Furkan Tüzün",
                "Enes Bartu Ünal",
                "Tolga Karadoğan",
                "Naci Yirik",
                "Yiğit Arif Memeci"
            };
        }

        private void bTemizle_Click(object sender, EventArgs e)
        {
            tbAd.Clear();
            tbSoyad.Text = "";
        }

        private void bAra_Click(object sender, EventArgs e)
        {
            //string bugun = "Çarşamba"; // local değişken
            foreach (var personel in personeller)
            {
                if (personel.Contains(tbAd.Text + " " + tbSoyad.Text))
                    MessageBox.Show(personel);
                else
                    MessageBox.Show("Bulunamadı!");

            }
            
        }


    }
}
