﻿namespace WindowsFormsGiris
{
    partial class OgrenciBilgileri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.dtpIslemTarihi = new System.Windows.Forms.DateTimePicker();
            this.cbCaliskan = new System.Windows.Forms.CheckBox();
            this.rbErkek = new System.Windows.Forms.RadioButton();
            this.rbKadin = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.cbSehir = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.nudYas = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.tbSoyadi = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbAdi = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudYas)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.dtpIslemTarihi);
            this.panel1.Controls.Add(this.cbCaliskan);
            this.panel1.Controls.Add(this.rbErkek);
            this.panel1.Controls.Add(this.rbKadin);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.cbSehir);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.nudYas);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.tbSoyadi);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.tbAdi);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(776, 353);
            this.panel1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(76, 257);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "Kaydet";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 236);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "İşlem Tarihi";
            // 
            // dtpIslemTarihi
            // 
            this.dtpIslemTarihi.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpIslemTarihi.Location = new System.Drawing.Point(76, 230);
            this.dtpIslemTarihi.Name = "dtpIslemTarihi";
            this.dtpIslemTarihi.Size = new System.Drawing.Size(200, 20);
            this.dtpIslemTarihi.TabIndex = 12;
            // 
            // cbCaliskan
            // 
            this.cbCaliskan.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbCaliskan.Checked = true;
            this.cbCaliskan.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbCaliskan.Location = new System.Drawing.Point(13, 179);
            this.cbCaliskan.Name = "cbCaliskan";
            this.cbCaliskan.Size = new System.Drawing.Size(104, 24);
            this.cbCaliskan.TabIndex = 11;
            this.cbCaliskan.Text = "Çalışkan mı?";
            this.cbCaliskan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbCaliskan.UseVisualStyleBackColor = true;
            // 
            // rbErkek
            // 
            this.rbErkek.AutoSize = true;
            this.rbErkek.Location = new System.Drawing.Point(123, 143);
            this.rbErkek.Name = "rbErkek";
            this.rbErkek.Size = new System.Drawing.Size(53, 17);
            this.rbErkek.TabIndex = 10;
            this.rbErkek.TabStop = true;
            this.rbErkek.Text = "Erkek";
            this.rbErkek.UseVisualStyleBackColor = true;
            // 
            // rbKadin
            // 
            this.rbKadin.AutoSize = true;
            this.rbKadin.Location = new System.Drawing.Point(65, 143);
            this.rbKadin.Name = "rbKadin";
            this.rbKadin.Size = new System.Drawing.Size(52, 17);
            this.rbKadin.TabIndex = 9;
            this.rbKadin.TabStop = true;
            this.rbKadin.Text = "Kadın";
            this.rbKadin.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 148);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Cinsiyet";
            // 
            // cbSehir
            // 
            this.cbSehir.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSehir.FormattingEnabled = true;
            this.cbSehir.Items.AddRange(new object[] {
            "Ankara",
            "İstanbul",
            "İzmir"});
            this.cbSehir.Location = new System.Drawing.Point(65, 101);
            this.cbSehir.Name = "cbSehir";
            this.cbSehir.Size = new System.Drawing.Size(177, 21);
            this.cbSehir.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Şehir";
            // 
            // nudYas
            // 
            this.nudYas.Location = new System.Drawing.Point(65, 68);
            this.nudYas.Maximum = new decimal(new int[] {
            45,
            0,
            0,
            0});
            this.nudYas.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudYas.Name = "nudYas";
            this.nudYas.Size = new System.Drawing.Size(177, 20);
            this.nudYas.TabIndex = 5;
            this.nudYas.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Yaş";
            // 
            // tbSoyadi
            // 
            this.tbSoyadi.Location = new System.Drawing.Point(65, 39);
            this.tbSoyadi.MaxLength = 50;
            this.tbSoyadi.Name = "tbSoyadi";
            this.tbSoyadi.Size = new System.Drawing.Size(177, 20);
            this.tbSoyadi.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Soyadı";
            // 
            // tbAdi
            // 
            this.tbAdi.Location = new System.Drawing.Point(65, 12);
            this.tbAdi.MaxLength = 50;
            this.tbAdi.Name = "tbAdi";
            this.tbAdi.Size = new System.Drawing.Size(177, 20);
            this.tbAdi.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Adı";
            // 
            // OgrenciBilgileri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Name = "OgrenciBilgileri";
            this.Text = "Öğrenci Bilgileri";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudYas)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cbSehir;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nudYas;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbSoyadi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbAdi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rbErkek;
        private System.Windows.Forms.RadioButton rbKadin;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox cbCaliskan;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dtpIslemTarihi;
        private System.Windows.Forms.Button button1;
    }
}