﻿using System;
using System.Windows.Forms;

namespace BarbutOOP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bYeniOyun_Click(object sender, EventArgs e)
        {
            Temizle();
        }

        void Temizle()
        {
            lZar1.Text = "";
            lZar2.Text = "";
            lbSonuc.Items.Clear();
        }

        private void bZarAt_Click(object sender, EventArgs e)
        {
            ZarAt();
        }

        void ZarAt() // Recursive method
        {
            Zar zar = new Zar();
            int zar1Index, zar2Index;
            lZar1.Text = zar.ZarAt();
            zar1Index = zar.ZarIndexi;
            lZar2.Text = zar.ZarAt();
            zar2Index = zar.ZarIndexi;
            if (zar1Index > zar2Index)
            {
                lbSonuc.Items.Add("1. zar kazandı.");
            }
            else if (zar1Index < zar2Index)
            {
                lbSonuc.Items.Add("2. zar kazandı.");
            }
            else
            {
                ZarAt();
            }
        }
    }
}
