﻿using System;

namespace BarbutOOP
{
    class Zar // SOLID: Single Responsibility
    {
        string[] _zarYazilari = new string[]
        {
            "   \n * \n   ", // 1
            "  *\n   \n*  ", // 2
            "  *\n * \n*  ", // 3
            "* *\n   \n* *", // 4
            "* *\n * \n* *", // 5
            "***\n   \n***" // 6
        };
        public int ZarIndexi { get; set; }
        Random random = new Random();

        public string ZarAt()
        {
            ZarIndexi = random.Next(0, 6);
            return _zarYazilari[ZarIndexi];
        }
    }
}
