﻿using System;

namespace ArabaVeSurucu
{
    class Program
    {
        static void Main(string[] args)
        {
            SurucuBase surucu = new Surucu()
            {
                Name = "Çağıl Alsaç"
            };
            Araba araba = new Araba(surucu);
            araba.Sur();

            Console.ReadLine();
        }
    }

    class Araba
    {
        private readonly SurucuBase _surucu;

        public Araba(SurucuBase surucu)
        {
            _surucu = surucu;
        }

        public void Sur()
        {
            Console.Write("Araba " + _surucu.Name + " tarafından sürülüyor.");
        }
    }

    abstract class SurucuBase
    {
        public string Name { get; set; }
    }

    class Surucu : SurucuBase
    {
       
    }
}
