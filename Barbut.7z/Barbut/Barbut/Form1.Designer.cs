﻿namespace Barbut
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bZarAt = new System.Windows.Forms.Button();
            this.lZar1 = new System.Windows.Forms.Label();
            this.lZar2 = new System.Windows.Forms.Label();
            this.lSonuc = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bZarAt
            // 
            this.bZarAt.Location = new System.Drawing.Point(15, 25);
            this.bZarAt.Name = "bZarAt";
            this.bZarAt.Size = new System.Drawing.Size(75, 23);
            this.bZarAt.TabIndex = 1;
            this.bZarAt.Text = "Zar At";
            this.bZarAt.UseVisualStyleBackColor = true;
            this.bZarAt.Click += new System.EventHandler(this.bZarAt_Click);
            // 
            // lZar1
            // 
            this.lZar1.AutoSize = true;
            this.lZar1.Location = new System.Drawing.Point(12, 9);
            this.lZar1.Name = "lZar1";
            this.lZar1.Size = new System.Drawing.Size(31, 13);
            this.lZar1.TabIndex = 2;
            this.lZar1.Text = "lZar1";
            // 
            // lZar2
            // 
            this.lZar2.AutoSize = true;
            this.lZar2.Location = new System.Drawing.Point(49, 9);
            this.lZar2.Name = "lZar2";
            this.lZar2.Size = new System.Drawing.Size(31, 13);
            this.lZar2.TabIndex = 3;
            this.lZar2.Text = "lZar2";
            // 
            // lSonuc
            // 
            this.lSonuc.AutoSize = true;
            this.lSonuc.Location = new System.Drawing.Point(12, 51);
            this.lSonuc.Name = "lSonuc";
            this.lSonuc.Size = new System.Drawing.Size(40, 13);
            this.lSonuc.TabIndex = 4;
            this.lSonuc.Text = "lSonuc";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(199, 78);
            this.Controls.Add(this.lSonuc);
            this.Controls.Add(this.lZar2);
            this.Controls.Add(this.lZar1);
            this.Controls.Add(this.bZarAt);
            this.Name = "Form1";
            this.Text = "Barbut";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bZarAt;
        private System.Windows.Forms.Label lZar1;
        private System.Windows.Forms.Label lZar2;
        private System.Windows.Forms.Label lSonuc;
    }
}

