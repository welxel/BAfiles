﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Barbut
{
    public partial class Form1 : Form
    {
        //Random rasgele = new Random();
        Random rasgele;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            rasgele = new Random();
        }

        private void bZarAt_Click(object sender, EventArgs e)
        {
            Oyna();
        }

        private void Oyna()
        {
            //int rasgeleSayi1 = rasgele.Next(1, 7);
            //lZar1.Text = rasgeleSayi1.ToString();
            lZar1.Text = RasgeleSayiOlustur();
            //int rasgeleSayi2 = rasgele.Next(1, 7);
            //lZar2.Text = rasgeleSayi2.ToString();
            lZar2.Text = RasgeleSayiOlustur();
            SonucuKontrolEt();
        }

        private void SonucuKontrolEt()
        {
            int rasgeleSayi1 = Convert.ToInt32(lZar1.Text);
            int rasgeleSayi2 = Convert.ToInt32(lZar2.Text);
            if (rasgeleSayi1 > rasgeleSayi2)
            {
                lSonuc.Text = "1. zar kazandı.";
            }
            else if (rasgeleSayi1 < rasgeleSayi2)
            {
                lSonuc.Text = "2. zar kazandı.";
            }
            else
            {
                //lSonuc.Text = "Berabere.";
                Oyna();
            }
        }

        string RasgeleSayiOlustur()
        {
            int rasgeleSayi = rasgele.Next(1, 7);
            return rasgeleSayi.ToString();
        }
    }
}
