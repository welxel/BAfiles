﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IsimBulma
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Insan> insanlar = new List<Insan>();
            Insan insan;
            insan = new Insan();
            insan.Id = 1;
            insan.Adi = "Çağıl";
            insan.Soyadi = "Alsaç";
            insanlar.Add(insan);
            insan = new Insan()
            {
                Id = 2,
                Adi = "Leo",
                Soyadi = "Alsaç"
            };
            insanlar.Add(insan);
            insan = new Insan(3, "Angel", "Alsaç");
            insanlar.Add(insan);
            foreach (var i in insanlar)
            {
                Console.WriteLine(i.Id + ") " + i.Adi + " " + i.Soyadi);
            }
            Console.Write("Ad giriniz: ");
            string ad = Console.ReadLine();
            Console.Write("Soyad giriniz: ");
            string soyad = Console.ReadLine();

            //1. yol:
            foreach (var i in insanlar)
            {
                if (i.Adi.ToLower().Contains(ad.ToLower()) && i.Soyadi.ToLower().Contains(soyad.ToLower()))
                {
                    Console.WriteLine(i.Id + ") " + i.Adi + " " + i.Soyadi);
                    break;
                }
            }

            //2. yol:
            Insan sonuc = InsanBul(insanlar, ad, soyad);
            if (sonuc != null)
                Console.WriteLine(sonuc.Adi + " " + sonuc.Soyadi);

            //3. yol:
            Insan sonucInsan = insanlar.FirstOrDefault(i => i.Adi.ToLower().Contains(ad.ToLower()) && i.Soyadi.ToLower().Contains(soyad.ToLower())); // FirstOrDefault, LastOrDefault, SingleOrDefault, => lambda, LINQ (language integrated query)

            if (sonucInsan != null)
                Console.WriteLine("FirstOrDefault: " + sonuc.Adi + " " + sonuc.Soyadi);
            else
                Console.WriteLine("Bulunamadı");

            Console.ReadLine();

        }

        private static Insan InsanBul(List<Insan> insanlar, string ad, string soyad, Insan insan = null)
        {
            if (insanlar[0].Adi.ToLower().Contains(ad.ToLower()) && insanlar[0].Soyadi.ToLower().Contains(soyad.ToLower()))
            {
                return insanlar[0];
            }
            else
            {
                insanlar.RemoveAt(0);
                if (insanlar.Count > 0)
                    insan = InsanBul(insanlar, ad, soyad, insan);
            }
            return insan;
        }
    }

    class Insan
    {
        public int Id { get; set; }
        public string Adi { get; set; }
        public string Soyadi { get; set; }

        public Insan(int id, string adi, string soyadi)
        {
            Id = id;
            Adi = adi;
            Soyadi = soyadi;
        }

        public Insan()
        {
            Id = 0;
            Adi = "";
            Soyadi = "";
        }
    }
}
