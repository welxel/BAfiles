﻿using Ogrenciler.Classes;
using System;
using System.Collections.Generic;

namespace Ogrenciler
{
    class Program
    {
        static void Main(string[] args)
        {
            //HafizaIslemleri hafizaIslemleri = new HafizaIslemleri();
            //DosyaIslemleri dosyaIslemleri = new DosyaIslemleri();
            //List<Ogrenci> ogrenciListesi = hafizaIslemleri.ListeyiGetir();
            //List<Ogrenci> ogrenciListesi = dosyaIslemleri.ListeyiGetir();
            IIslemler islemler = new DosyaIslemleri();
            List<Ogrenci> ogrenciListesi = islemler.ListeyiGetir();
            OgrenciServis ogrenciServis = new OgrenciServis();
            ogrenciServis.Goster(ogrenciListesi);

            Console.Write("Yeni öğrenci adı: ");
            string girilenOgrenciAdi = Console.ReadLine();
            Console.Write("Yeni öğrenci soyadı: ");
            string girilenOgrenciSoyadi = Console.ReadLine();
            Console.Write("Yeni öğrenci Counter Strike seviyesi (İyi: 3, Orta: 2, Kötü: 1, Belirsiz: 0): ");
            int girilenCsSeviye = Convert.ToInt32(Console.ReadLine());

            Ogrenci girilenOgrenci = new Ogrenci()
            {
                Adi = girilenOgrenciAdi,
                Soyadi = girilenOgrenciSoyadi,
                CsSeviyesi = (CsSeviyeEnum)girilenCsSeviye
            };

            ogrenciServis.Ekle(girilenOgrenci, ogrenciListesi, false);
            ogrenciServis.Goster(ogrenciListesi);

            Console.ReadLine();
        }
    }
}
