﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Ogrenciler.Classes
{
    class OgrenciServis
    {
        public void Goster(List<Ogrenci> ogrenciler)
        {
            Console.WriteLine("Öğrenci Listesi");
            foreach (var ogrenci in ogrenciler)
            {
                Console.WriteLine(ogrenci.Id + " - " + ogrenci.Adi + " " + ogrenci.Soyadi + " (" + ogrenci.CsSeviyesi + ")");
            }
        }

        public void Ekle(Ogrenci ogrenci, List<Ogrenci> ogrenciler, bool hafizayaEkle = true)
        {
            try
            {
                List<int> idler = new List<int>();
                foreach (var o in ogrenciler)
                {
                    idler.Add(o.Id);
                }
                int yeniId = idler.Max();
                ogrenci.Id = yeniId + 1;
                ogrenciler.Add(ogrenci);
                if (!hafizayaEkle)
                {
                    string dosyaLine = ogrenci.Id + ";" + ogrenci.Adi + ";" + ogrenci.Soyadi + ";" + (int)ogrenci.CsSeviyesi;
                    string path = @"C:\Dosyalar\Öğrenciler.txt";
                    File.AppendAllText(path, dosyaLine);
                }
            }
            catch (Exception exc)
            {
                Console.WriteLine("Hata: " + exc.Message);
            }
        }
    }
}
