﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ogrenciler.Classes
{
    class DosyaIslemleri : IIslemler
    {
        public List<Ogrenci> ListeyiGetir()
        {
            try
            {
                // StreamReader, StreamWriter, FileInfo
                string pathDosya = @"C:\Dosyalar\Öğrenciler.txt";
                //string path = Application.StartupPath + @"\Öğrenciler.txt"; // C:\Users\Administrator\Desktop\Ogrenciler\Ogrenciler\bin\Debug Windows Forms
                IEnumerable<string> linesDosya = File.ReadLines(pathDosya);
                List<Ogrenci> dosyaOgrenciListesi = new List<Ogrenci>();
                Ogrenci ogrenciDosya;
                foreach (var line in linesDosya)
                {
                    ogrenciDosya = new Ogrenci()
                    {
                        Id = Convert.ToInt32(line.Split(';')[0]),
                        Adi = line.Split(';')[1],
                        Soyadi = line.Split(';')[2],
                        CsSeviyesi = (CsSeviyeEnum)Convert.ToInt32(line.Split(';')[3]) // bu bir enum olduğu için int değer CsSeviyeEnum'a cast edilmeli (dönüştürülmeli)
                    };
                    dosyaOgrenciListesi.Add(ogrenciDosya);
                }
                return dosyaOgrenciListesi;
            }
            catch (Exception exc)
            {
                Console.WriteLine("Hata: " + exc.Message);
                return null;
            }
        }
    }
}
