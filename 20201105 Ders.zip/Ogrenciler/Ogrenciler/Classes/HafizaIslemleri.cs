﻿using System.Collections.Generic;

namespace Ogrenciler.Classes
{
    class HafizaIslemleri : IIslemler
    {
        public List<Ogrenci> ListeyiGetir()
        {
            List<Ogrenci> ogrenciler = new List<Ogrenci>()
            {
                new Ogrenci()
                {
                    Id = 1,
                    Adi = "Yiğit",
                    Soyadi = "Memeci",
                    CsSeviyesi = CsSeviyeEnum.İyi
                },
                new Ogrenci()
                {
                    Id = 2,
                    Adi = "Bartu",
                    Soyadi = "Ünal",
                    CsSeviyesi = CsSeviyeEnum.Orta
                },
                new Ogrenci()
                {
                    Id = 3,
                    Adi = "Mert",
                    Soyadi = "Kandemir",
                    CsSeviyesi = CsSeviyeEnum.Belirsiz
                }
            };
            return ogrenciler;
        }
    }
}
