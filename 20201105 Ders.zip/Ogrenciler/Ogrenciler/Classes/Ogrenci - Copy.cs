﻿namespace Ogrenciler.Classes
{
    class Ogrenci
    {
        public int Id { get; set; }
        public string Adi { get; set; }
        public string Soyadi { get; set; }
        public CsSeviyeEnum CsSeviyesi { get; set; }
    }
}
