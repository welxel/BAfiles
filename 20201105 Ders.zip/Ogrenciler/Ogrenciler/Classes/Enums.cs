﻿namespace Ogrenciler.Classes
{
    enum CsSeviyeEnum // Counter Strike seviye bilgileri
    {
        İyi = 3,
        Orta = 2,
        Kötü = 1,
        Belirsiz = 0
    }
}
