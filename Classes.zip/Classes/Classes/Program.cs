﻿using System;
using Classes.Customers.Concretes;
using Classes.Students;

namespace Classes
{
    class Program
    {
        static void Main(string[] args)
        {
            Person insan = new Person(); // initialization, insan bir instance (obje)
            insan.Run();
            CustomerService customerService = new CustomerService();
            customerService.Add();
            customerService.Update();
            customerService.Delete();
            CustomerService customerService1; // camel case c, S
            //customerService1.Add();
            var productService = new ProductService();
            productService.Add();
            productService.Update();
            productService.Delete();
            //productService.AddUpdateDelete();
            EmployeeService employeeService = new EmployeeService();
            //Classes.Students.Student student = new Classes.Students.Student();
            Student student = new Student();
            student.List();
            Customer customer = new Customer();
            customer.Name = "Çağıl";
            customer.Surname = "Alsaç";
            customer.SetAge(40);
            customer.City = "Ankara";
            customer.Id = 1;
            customer.country = "Türkiye"; // public alanlar kullanılmaz, bunun yerine encapsulation yapılır
            Console.WriteLine("Id: " + customer.Id + "\nName: " + customer.Name + " " + customer.Surname + "\nAge: " + customer.GetAge() + "\nCity: " + customer.City + "\nCountry: " + customer.country);




            Console.ReadLine();
        }
    }

    class Person
    {
        public void Run() // behavior yani davranış
        {
            Console.WriteLine("Person is running...");
        }
    }

    class CustomerService // müşteri ile ilgili yapılabilecek işlemler
    {
        public void Add()
        {
            Console.WriteLine("Added");
        }

        public void Update()
        {
            Console.WriteLine("Updated");
        }

        public void Delete()
        {
            Console.WriteLine("Deleted");
        }
    }

    class ProductService
    {
        public void Add()
        {
            Console.WriteLine("Added");
        }

        public void Update()
        {
            Console.WriteLine("Updated");
        }

        public void Delete()
        {
            Console.WriteLine("Deleted");
        }

        public void AddUpdateDelete()
        {
            this.Add();
            this.Update();
            this.Delete();
        }
    }
}
