﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes.Customers.Concretes
{
    class Customer
    {
        #region Properties (Özellikler)
        public int Id { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string City { get; set; }
        #endregion

        #region Fields (Alanlar)
        //string _name;
        //string _surname;
        int age;
        public string country; // sakın yapmayın
        #endregion

        #region Behaviors (Davranışlar)
        //public void SetName(string name) // encapsulation
        //{
        //    _name = name;
        //}

        //public string GetName() // encapsulation
        //{
        //    return _name;
        //}

        //public void SetSurname(string surname)
        //{
        //    _surname = surname;
        //}

        //public string GetSurname()
        //{
        //    return _surname;
        //}

        public void SetAge(int age)
        {
            this.age = age;
        }

        public int GetAge()
        {
            return age;
        }

        // sakın böyle yapmayın!
        //public string GetSetName(string name = "")
        //{
        //    if (name != "")
        //    {
        //        _name = name;
        //        return _name;
        //    }
        //    else
        //    {
        //        return _name;
        //    }
        //}
        #endregion
    }
}
