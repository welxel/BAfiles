﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KoronavirusTespit
{
    public partial class BelirtiTespitForm : Form
    {
        string[] sehirler = new string[]
        {
            "Ankara",
            "İstanbul",
            "İzmir"
        };

        public BelirtiTespitForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            KontrolEt();
        }

        private void KontrolEt()
        {
            tbSonuc.Text = "";
            if (rbKadin.Checked)
                tbSonuc.Text += "Bayan ";
            else
                tbSonuc.Text += "Bay ";
            tbSonuc.Text += tbAd.Text + " " + tbSoyad.Text;
            tbSonuc.Text += " (" + cbSehir.Text + ")";
            tbSonuc.Text += " test tarihiniz: " + dtpTarih.Value.ToShortDateString();
            tbSonuc.Text += " yaşınız: " + nudYas.Value;
            if (cbAtes.Checked || (cbOksuruk.Checked && cbBogazAgrisi.Checked))
                tbSonuc.Text += " Koronavirus olabilirsin.";
            else
                tbSonuc.Text += " Koronavirus olmayabilirsin.";
        }

        private void cbAtes_CheckedChanged(object sender, EventArgs e)
        {
            if (cbAtes.Checked)
            {
                cbBogazAgrisi.Checked = false;
                cbBogazAgrisi.Enabled = false;
                cbOksuruk.Checked = false;
                cbOksuruk.Enabled = false;
            }
            else
            {
                cbBogazAgrisi.Enabled = true;
                cbOksuruk.Enabled = true;
                tbSonuc.Text = "";
            }
            KontrolEt();
        }

        private void BelirtiTespitForm_Load(object sender, EventArgs e)
        {
            cbSehir.Items.AddRange(sehirler);
            cbSehir.SelectedIndex = 1;
            dtpTarih.Value = DateTime.Now;
            rbKadin.Checked = true;
        }
    }
}
