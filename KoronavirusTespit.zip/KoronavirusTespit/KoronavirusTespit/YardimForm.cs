﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KoronavirusTespit
{
    public partial class YardimForm : Form
    {
        string yardimText = "Yardım Sayfası";

        public YardimForm()
        {
            InitializeComponent();
        }

        private void YardimForm_Load(object sender, EventArgs e)
        {
            lYardim.Text = yardimText;
        }

        private void link_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            webBrowser.Visible = !webBrowser.Visible;
            //if (webBrowser.Visible)
            //    webBrowser.Visible = false;
            //else
            //    webBrowser.Visible = true;
        }
    }
}
