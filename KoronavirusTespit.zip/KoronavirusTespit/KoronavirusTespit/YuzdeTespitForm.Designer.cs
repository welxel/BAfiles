﻿namespace KoronavirusTespit
{
    partial class YuzdeTespitForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbAtes = new System.Windows.Forms.CheckBox();
            this.cbOksuruk = new System.Windows.Forms.CheckBox();
            this.cbBogazAgrisi = new System.Windows.Forms.CheckBox();
            this.bYuzde = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tbAdSoyad = new System.Windows.Forms.TextBox();
            this.lbListe = new System.Windows.Forms.ListBox();
            this.bTemizle = new System.Windows.Forms.Button();
            this.bRapor = new System.Windows.Forms.Button();
            this.lRapor = new System.Windows.Forms.Label();
            this.gbRapor = new System.Windows.Forms.GroupBox();
            this.gbRapor.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbAtes
            // 
            this.cbAtes.AutoSize = true;
            this.cbAtes.Location = new System.Drawing.Point(12, 43);
            this.cbAtes.Name = "cbAtes";
            this.cbAtes.Size = new System.Drawing.Size(47, 17);
            this.cbAtes.TabIndex = 0;
            this.cbAtes.Text = "Ateş";
            this.cbAtes.UseVisualStyleBackColor = true;
            // 
            // cbOksuruk
            // 
            this.cbOksuruk.AutoSize = true;
            this.cbOksuruk.Location = new System.Drawing.Point(12, 67);
            this.cbOksuruk.Name = "cbOksuruk";
            this.cbOksuruk.Size = new System.Drawing.Size(66, 17);
            this.cbOksuruk.TabIndex = 1;
            this.cbOksuruk.Text = "Öksürük";
            this.cbOksuruk.UseVisualStyleBackColor = true;
            // 
            // cbBogazAgrisi
            // 
            this.cbBogazAgrisi.AutoSize = true;
            this.cbBogazAgrisi.Location = new System.Drawing.Point(12, 91);
            this.cbBogazAgrisi.Name = "cbBogazAgrisi";
            this.cbBogazAgrisi.Size = new System.Drawing.Size(84, 17);
            this.cbBogazAgrisi.TabIndex = 2;
            this.cbBogazAgrisi.Text = "Boğaz Ağrısı";
            this.cbBogazAgrisi.UseVisualStyleBackColor = true;
            // 
            // bYuzde
            // 
            this.bYuzde.Location = new System.Drawing.Point(12, 125);
            this.bYuzde.Name = "bYuzde";
            this.bYuzde.Size = new System.Drawing.Size(142, 23);
            this.bYuzde.TabIndex = 3;
            this.bYuzde.Text = "Yüzde Hesapla ve Ekle";
            this.bYuzde.UseVisualStyleBackColor = true;
            this.bYuzde.Click += new System.EventHandler(this.bYuzde_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Ad Soyad";
            // 
            // tbAdSoyad
            // 
            this.tbAdSoyad.Location = new System.Drawing.Point(72, 5);
            this.tbAdSoyad.Name = "tbAdSoyad";
            this.tbAdSoyad.Size = new System.Drawing.Size(378, 20);
            this.tbAdSoyad.TabIndex = 5;
            // 
            // lbListe
            // 
            this.lbListe.FormattingEnabled = true;
            this.lbListe.Location = new System.Drawing.Point(15, 155);
            this.lbListe.Name = "lbListe";
            this.lbListe.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lbListe.Size = new System.Drawing.Size(435, 277);
            this.lbListe.TabIndex = 6;
            // 
            // bTemizle
            // 
            this.bTemizle.Location = new System.Drawing.Point(160, 125);
            this.bTemizle.Name = "bTemizle";
            this.bTemizle.Size = new System.Drawing.Size(142, 23);
            this.bTemizle.TabIndex = 3;
            this.bTemizle.Text = "Temizle";
            this.bTemizle.UseVisualStyleBackColor = true;
            this.bTemizle.Click += new System.EventHandler(this.bTemizle_Click);
            // 
            // bRapor
            // 
            this.bRapor.Location = new System.Drawing.Point(308, 125);
            this.bRapor.Name = "bRapor";
            this.bRapor.Size = new System.Drawing.Size(142, 23);
            this.bRapor.TabIndex = 7;
            this.bRapor.Text = "Rapor";
            this.bRapor.UseVisualStyleBackColor = true;
            this.bRapor.Click += new System.EventHandler(this.bRapor_Click);
            // 
            // lRapor
            // 
            this.lRapor.AutoSize = true;
            this.lRapor.Location = new System.Drawing.Point(6, 29);
            this.lRapor.Name = "lRapor";
            this.lRapor.Size = new System.Drawing.Size(38, 13);
            this.lRapor.TabIndex = 8;
            this.lRapor.Text = "lRapor";
            // 
            // gbRapor
            // 
            this.gbRapor.Controls.Add(this.lRapor);
            this.gbRapor.Location = new System.Drawing.Point(456, 5);
            this.gbRapor.Name = "gbRapor";
            this.gbRapor.Size = new System.Drawing.Size(332, 427);
            this.gbRapor.TabIndex = 9;
            this.gbRapor.TabStop = false;
            this.gbRapor.Text = "Rapor";
            this.gbRapor.Visible = false;
            // 
            // YuzdeTespitForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.gbRapor);
            this.Controls.Add(this.bRapor);
            this.Controls.Add(this.lbListe);
            this.Controls.Add(this.tbAdSoyad);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bTemizle);
            this.Controls.Add(this.bYuzde);
            this.Controls.Add(this.cbBogazAgrisi);
            this.Controls.Add(this.cbOksuruk);
            this.Controls.Add(this.cbAtes);
            this.Name = "YuzdeTespitForm";
            this.Text = "Yüzde Tespit";
            this.gbRapor.ResumeLayout(false);
            this.gbRapor.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox cbAtes;
        private System.Windows.Forms.CheckBox cbOksuruk;
        private System.Windows.Forms.CheckBox cbBogazAgrisi;
        private System.Windows.Forms.Button bYuzde;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbAdSoyad;
        private System.Windows.Forms.ListBox lbListe;
        private System.Windows.Forms.Button bTemizle;
        private System.Windows.Forms.Button bRapor;
        private System.Windows.Forms.Label lRapor;
        private System.Windows.Forms.GroupBox gbRapor;
    }
}