﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KoronavirusTespit
{
    public partial class YuzdeTespitForm : Form
    {
        public YuzdeTespitForm()
        {
            InitializeComponent();
        }

        private void bYuzde_Click(object sender, EventArgs e)
        {
            int yuzde = 0;
            string sonuc;
            if (cbAtes.Checked)
                yuzde += 70;
            if (cbOksuruk.Checked)
                yuzde += 20;
            if (cbBogazAgrisi.Checked)
                yuzde += 10;
            sonuc = "Sayın " + tbAdSoyad.Text + ", ";
            sonuc += "Koronavirus olma ihtimaliniz %" + yuzde;
            lbListe.Items.Add(sonuc);
        }

        private void bTemizle_Click(object sender, EventArgs e)
        {
            tbAdSoyad.Text = "";
            cbAtes.Checked = false;
            cbOksuruk.Checked = false;
            cbBogazAgrisi.Checked = false;
            lbListe.Items.Clear();
            lRapor.Text = "";
            gbRapor.Visible = false;
        }

        private void bRapor_Click(object sender, EventArgs e)
        {
            lRapor.Text = "";
            if (lbListe.Items.Count > 0)
            {
                foreach (var item in lbListe.Items)
                {
                    lRapor.Text += item + "\n";
                }
            }
            gbRapor.Visible = true;
        }
    }
}
