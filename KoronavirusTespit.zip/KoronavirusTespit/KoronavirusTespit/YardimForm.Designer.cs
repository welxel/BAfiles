﻿namespace KoronavirusTespit
{
    partial class YardimForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lYardim = new System.Windows.Forms.Label();
            this.webBrowser = new System.Windows.Forms.WebBrowser();
            this.link = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // lYardim
            // 
            this.lYardim.AutoSize = true;
            this.lYardim.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lYardim.Location = new System.Drawing.Point(12, 9);
            this.lYardim.Name = "lYardim";
            this.lYardim.Size = new System.Drawing.Size(88, 29);
            this.lYardim.TabIndex = 0;
            this.lYardim.Text = "lYardim";
            // 
            // webBrowser
            // 
            this.webBrowser.Location = new System.Drawing.Point(17, 74);
            this.webBrowser.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser.Name = "webBrowser";
            this.webBrowser.Size = new System.Drawing.Size(947, 556);
            this.webBrowser.TabIndex = 1;
            this.webBrowser.Url = new System.Uri("https://covid19.saglik.gov.tr/", System.UriKind.Absolute);
            this.webBrowser.Visible = false;
            // 
            // link
            // 
            this.link.AutoSize = true;
            this.link.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.link.Location = new System.Drawing.Point(14, 48);
            this.link.Name = "link";
            this.link.Size = new System.Drawing.Size(426, 23);
            this.link.TabIndex = 2;
            this.link.TabStop = true;
            this.link.Text = "Sağlık Bakanlığı sayfasını görebilmek için tıklayın";
            this.link.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.link_LinkClicked);
            // 
            // YardimForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(976, 642);
            this.Controls.Add(this.link);
            this.Controls.Add(this.webBrowser);
            this.Controls.Add(this.lYardim);
            this.Name = "YardimForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Yardım";
            this.Load += new System.EventHandler(this.YardimForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lYardim;
        private System.Windows.Forms.WebBrowser webBrowser;
        private System.Windows.Forms.LinkLabel link;
    }
}