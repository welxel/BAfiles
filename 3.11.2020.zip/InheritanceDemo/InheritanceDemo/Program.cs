﻿using InheritanceDemo.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Circle circle = new Circle();
            circle.IsPiThree = false;
            circle.Radius = 3;
            double area = circle.CalculateArea();
            double circumference = circle.CalculateCircumference();

            ShapeWithAngleBase shape = new RightTriangle(); // polymorphism
            shape = new Rectangle();

            RightTriangle triangle = new RightTriangle();
            area = triangle.CalculateArea();
            circumference = triangle.CalculateCircumference();
            Console.WriteLine("Area: " + area + ", circumference: " + circumference);
            triangle = new RightTriangle(6, 8);
            area = triangle.CalculateArea();
            circumference = triangle.CalculateCircumference();
            Console.WriteLine("Area: " + area + ", circumference: " + circumference);

            Rectangle rectangle = new Rectangle()
            {
                Height = 4,
                Width = 4
            };
            area = rectangle.CalculateArea();
            circumference = rectangle.CalculateCircumference();
            Console.WriteLine("Area: " + area + ", circumference: " + circumference);

            Console.ReadLine();
        }
    }
}
