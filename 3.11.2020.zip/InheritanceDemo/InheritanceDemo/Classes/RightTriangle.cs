﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo.Classes
{
    class RightTriangle : ShapeWithAngleBase, IShape
    {
        private double _hypotenus;

        // RightTriange rigthTriangle = new RightTriangle();
        public RightTriangle()
        {
            Width = 3;
            Height = 4;
            _hypotenus = Math.Sqrt(Math.Pow(Width, 2) + Math.Pow(Height, 2));
        }

        // RightTriange rigthTriangle = new RightTriangle(6, 8);
        public RightTriangle(double width, double height)
        {
            Width = width;
            Height = height;
            _hypotenus = Math.Sqrt(Math.Pow(Width, 2) + Math.Pow(Height, 2));
        }

        ~RightTriangle() // finalizer
        {
            // obje temizleme kodları
        }

        public double CalculateArea()
        {
            return Width * Height / 2;
        }

        public double CalculateCircumference()
        {
            return _hypotenus + Width + Height;
        }
    }
}
