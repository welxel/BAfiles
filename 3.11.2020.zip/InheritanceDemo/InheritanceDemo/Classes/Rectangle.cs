﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo.Classes
{
    class Rectangle : ShapeWithAngleBase, IShape, IDisposable
    {
        public double CalculateArea()
        {
            return Width * Height;
        }

        public double CalculateCircumference()
        {
            return (Width + Height) * 2;
        }

        #region Dispose Operation
        protected bool disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            this.disposed = true;
        }
        // Rectangle rectangle = new Rectangle();
        // rectangle.CalculateArea();
        // rectangle.Dispose();
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}
