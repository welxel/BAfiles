﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo.Classes
{
    class Circle : RoundedShapeBase
    {
        public override double CalculateArea()
        {
            return IsPiThree ? 3 * Radius * Radius : Math.PI * Radius * Radius;
        }

        public override double CalculateCircumference()
        {
            return IsPiThree ? 2 * 3 * Radius : 2 * Math.PI * Radius;
        }
    }
}
