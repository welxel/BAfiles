﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DependencyInjection
{
    class Program
    {
        static void Main(string[] args)
        {
            ILogger logger = new FileLogger();
            // property injection
            EmployeeManager manager = new EmployeeManager()
            {
                Logger = logger
            };
            manager.Add();
            // property injection
            MoneyManager moneyManager = new MoneyManager()
            {
                Logger = logger
            };
            moneyManager.Add();
            // method injection
            ProductManager productManager = new ProductManager();
            productManager.Add(logger);
            // constructor injection
            StudentManager studentManager = new StudentManager(logger);
            studentManager.Add();
            Console.ReadLine();
        }
    }

    interface ILogger
    {
        void Log();
    }

    class DatabaseLogger : ILogger
    {
        public void Log()
        {
            Console.WriteLine("Logged to database.");
        }
    }

    class FileLogger : ILogger
    {
        public void Log()
        {
            Console.WriteLine("Logged to file.");
        }
    }

    // property injection
    class EmployeeManager
    {
        public ILogger Logger { get; set; }

        public void Add()
        {
            Logger.Log();
            Console.WriteLine("Employee added.");
        }
    }

    // property injection
    class MoneyManager
    {
        public ILogger Logger { get; set; }

        public void Add()
        {
            Logger.Log();
            Console.WriteLine("Money added.");
        }
    }

    // method injection
    class ProductManager
    {
        public void Add(ILogger logger)
        {
            logger.Log();
            Console.WriteLine("Product added.");
        }
    }

    // constructor injection
    class StudentManager
    {
        private readonly ILogger _logger;

        public StudentManager(ILogger logger)
        {
            _logger = logger;
        }

        public void Add()
        {
            _logger.Log();
            Console.WriteLine("Student added.");
        }
    }
}
