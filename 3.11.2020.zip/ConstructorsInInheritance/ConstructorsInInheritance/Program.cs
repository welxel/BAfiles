﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorsInInheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            SubClass sub = new SubClass("Çağıl");
            sub.Display();
            Console.ReadLine();
        }
    }

    abstract class BaseClass
    {
        private string _baseField;

        public BaseClass(string baseField)
        {
            _baseField = baseField;
            Console.WriteLine("Base constructor executed.");
        }

        public void Display()
        {
            Console.Write(_baseField);
        }
    }

    class SubClass : BaseClass
    {
        public SubClass(string baseFieldParameter) : base(baseFieldParameter)
        {
            Console.WriteLine("Sub constructor executed.");
        }
    }
}
