﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlDatabaseOperations op = new SqlDatabaseOperations("server=1.2.3.4; database=personel;");
            Console.ReadLine();
        }
    }

    abstract class SqlDatabase
    {
        private string _connectionString;

        public SqlDatabase(string conStr)
        {
            _connectionString = conStr;
            Console.WriteLine(_connectionString);
        }

        public void Add()
        {

        }

        public void Update()
        {

        }

        public void Delete()
        {

        }
    }

    class SqlDatabaseOperations : SqlDatabase
    {
        public SqlDatabaseOperations(string conStr) : base(conStr)
        {
            
        }
    }
}
