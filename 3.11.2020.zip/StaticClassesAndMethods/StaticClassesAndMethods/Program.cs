﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticClassesAndMethods
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Config.connectionString);
            //Config.TimeOut = 30;
            Console.WriteLine(Config.TimeOut);
            Console.ReadLine();
        }
    }
}
