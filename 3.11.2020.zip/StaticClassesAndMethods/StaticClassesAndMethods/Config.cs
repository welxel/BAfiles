﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticClassesAndMethods
{
    static class Config
    {
        public static string connectionString = "Server=1.2.3;Database=Personel;"; // bunu tercih etmeyin
        public static int TimeOut => 30; // bunu kullanıyorum, readonly
    }
}
